/*
 * READS THE CHAT OPEN IN WHATSAPP WEB, only when the rep's Chat to Salesforce panel asks.
 *
 * Runs on web.whatsapp.com. It does nothing until the panel connects, reads only the chat open on
 * screen (#main), never the chat list, never another chat, and never sends, types or changes a
 * message: the only things it touches are WhatsApp's own "Read more" links (to see a long message
 * whole) and the chat's scroll position (to load earlier messages, put back where it was after).
 *
 * What it hands the panel are the rows as WhatsApp shows them; extension/whatsapp-web.js turns them
 * into chat lines. WhatsApp Web's page is not a published interface: everything here looks for the
 * few marks that have stayed put for years (#main, data-id, data-pre-plain-text) and says so
 * plainly when they are missing, so the panel can tell the rep instead of saving nothing.
 */
(() => {
    if (window.__chatToSalesforceReader) return;
    window.__chatToSalesforceReader = true;

    const READ_MORE = /^(Read more|Lire la suite|Mehr lesen|Leer más|Ler mais|Leggi altro|Meer lezen|Läs mer|Les mer|Læs mere)$/i;
    const TIME_ONLY = /^\d{1,2}[:.]\d{2}(\s?([AaPp]\.?\s?[Mm]\.?|上午|下午|午前|午後))?$/;
    const NOT_A_DAY = /unread|non lus?|ungelesen|no leíd|não lid|non lett|ongelezen|oläst|ulest|ulæst/i;
    const JID = /^(?:true|false)_(.+?@(?:c\.us|g\.us|lid|s\.whatsapp\.net|broadcast|newsletter))(?:_|$)/;
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

    const main = () => document.querySelector('#main');

    function chatInfo() {
        const m = main();
        if (!m) return null;
        const header = m.querySelector('header');
        let name = '';
        if (header) {
            const span = [...header.querySelectorAll('span[dir="auto"], span[title]')].find((s) => (s.getAttribute('title') || s.textContent || '').trim());
            if (span) name = (span.textContent || span.getAttribute('title') || '').trim();
        }
        const ids = m.querySelectorAll('[data-id]');
        let jid = '';
        for (const el of ids) {
            const j = JID.exec(el.getAttribute('data-id') || '');
            if (j) { jid = j[1]; break; }
        }
        return { name, jid, isGroup: /@g\.us$/.test(jid) };
    }

    function messageRows() {
        const m = main();
        if (!m) return [];
        const rows = [...m.querySelectorAll('[role="row"]')];
        if (rows.length) return rows;
        return [...m.querySelectorAll('[data-id]')].filter((el) => !el.parentElement.closest('[data-id]'));
    }

    /* The words of a message as WhatsApp would copy them: emoji pictures as their emoji, line breaks
     * kept, the quoted message it replies to and the "Read more" link left out. */
    function wordsOf(node, state) {
        let s = '';
        for (const child of node.childNodes) {
            if (child.nodeType === Node.TEXT_NODE) { s += child.data; continue; }
            if (child.nodeType !== Node.ELEMENT_NODE) continue;
            const el = child;
            if (el.tagName === 'BR') { s += '\n'; continue; }
            if (el.tagName === 'IMG') { s += el.getAttribute('alt') || el.getAttribute('data-plain-text') || ''; continue; }
            if (el.matches('[role="button"], .read-more-button') && READ_MORE.test((el.textContent || '').trim())) { state.cut = true; continue; }
            s += wordsOf(el, state);
        }
        return s;
    }

    function textIn(copyable, state) {
        const spans = [...copyable.querySelectorAll('span.selectable-text')].filter((sp) => {
            if (sp.parentElement && sp.parentElement.closest('span.selectable-text')) return false;
            if (sp.closest('.quoted-mention')) return false;
            const quote = sp.closest('[role="button"]');
            return !(quote && copyable.contains(quote) && quote !== copyable);
        });
        if (spans.length) return spans.map((sp) => wordsOf(sp, state)).join('\n').trim();
        return '';
    }

    function mediaIn(el) {
        const has = (sel) => !!el.querySelector(sel);
        const label = [...el.querySelectorAll('[aria-label]')].map((n) => n.getAttribute('aria-label')).join(' ').toLowerCase();
        if (has('audio, [data-icon*="ptt"], [data-icon*="audio-play"], [data-icon="audio-download"]') || /voice|audio|vocal|sprach/.test(label)) return 'voice';
        if (has('video, [data-icon*="media-play"], [data-icon*="video"]') || /\bvideo|vidéo/.test(label)) return 'video';
        if (has('[data-icon*="document"], [data-icon^="doc-"], [data-icon*="pdf"]') || /document|\bpdf\b|fichier|datei/.test(label)) return 'document';
        if (/sticker|autocollant/.test(label)) return 'sticker';
        if (has('[data-icon*="vcard"], [data-icon*="contact"]') || /contact card/.test(label)) return 'contact';
        const pics = [...el.querySelectorAll('img')].filter((img) => !img.classList.contains('emoji') && !img.hasAttribute('data-plain-text') &&
            ((img.getAttribute('src') || '').startsWith('blob:') || (img.getAttribute('src') || '').startsWith('data:image') || img.width >= 80 || Number(img.getAttribute('width')) >= 80));
        if (pics.length || /photo|picture|image|imagen|bild/.test(label)) return 'photo';
        return null;
    }

    function timeIn(el) {
        let found = null;
        el.querySelectorAll('span, div').forEach((n) => {
            if (n.children.length) return;
            const t = (n.textContent || '').replace(/[  ]/g, ' ').trim();
            if (TIME_ONLY.test(t)) found = t;
        });
        return found;
    }

    function readRow(row) {
        const idEl = row.matches('[data-id]') ? row : row.querySelector('[data-id]');
        if (!idEl) {
            const t = (row.textContent || '').trim();
            if (t && t.length <= 40 && !TIME_ONLY.test(t) && !NOT_A_DAY.test(t)) return { sep: t };
            return null;
        }
        const id = idEl.getAttribute('data-id') || '';
        const out = id.startsWith('true_') || !!idEl.querySelector('.message-out') || idEl.classList.contains('message-out') || !!idEl.closest('.message-out');
        const copyable = idEl.querySelector('[data-pre-plain-text]');
        const state = { cut: false };
        const text = copyable ? textIn(copyable, state) : '';
        return {
            id,
            out,
            pre: copyable ? copyable.getAttribute('data-pre-plain-text') : null,
            text,
            cut: state.cut,
            media: text ? null : mediaIn(idEl),
            time: copyable && text ? null : timeIn(idEl)
        };
    }

    function readAll() {
        return messageRows().map(readRow).filter(Boolean);
    }

    /* Rows read in several passes (while loading earlier messages) put back together, oldest first. */
    function merge(older, newer) {
        if (!older.length) return newer;
        const ids = new Set(newer.filter((x) => x.id).map((x) => x.id));
        const first = older.findIndex((x) => x.id && ids.has(x.id));
        if (first === -1) return older.concat(newer);
        let lastShared = first;
        older.forEach((x, i) => { if (x.id && ids.has(x.id)) lastShared = i; });
        return older.slice(0, first).concat(newer, older.slice(lastShared + 1).filter((x) => !x.id || !ids.has(x.id)));
    }

    function scroller() {
        let el = main() && main().querySelector('[data-id]');
        el = el && el.parentElement;
        while (el && el !== document.body) {
            const s = getComputedStyle(el);
            if (/(auto|scroll)/.test(s.overflowY) && el.scrollHeight > el.clientHeight + 10) return el;
            el = el.parentElement;
        }
        return null;
    }

    async function openLongMessages() {
        const m = main();
        if (!m) return;
        const links = [...m.querySelectorAll('[role="button"], .read-more-button')]
            .filter((b) => READ_MORE.test((b.textContent || '').trim()) && b.closest('[data-pre-plain-text]'));
        links.forEach((b) => { try { b.click(); } catch { /* left cut, and marked so */ } });
        if (links.length) await sleep(150);
    }

    function firstId() {
        const el = main() && main().querySelector('[data-id]');
        return el ? el.getAttribute('data-id') : null;
    }
    function idCount() {
        return main() ? main().querySelectorAll('[data-id]').length : 0;
    }

    async function waitFor(test, ms) {
        const until = Date.now() + ms;
        while (Date.now() < until) {
            if (test()) return true;
            await sleep(150);
        }
        return test();
    }

    let busy = false;

    async function read({ older = 0 } = {}) {
        if (!document.querySelector('#app')) return { status: 'loading' };
        const m = main();
        if (!m) {
            if (document.querySelector('#side')) return { status: 'no-chat' };
            if (document.querySelector('canvas[aria-label], [data-ref] canvas, div[data-ref]')) return { status: 'not-linked' };
            return { status: 'loading' };
        }
        busy = true;
        try {
            await openLongMessages();
            let items = readAll();
            let reachedStart = false;
            if (older > 0) {
                const sc = scroller();
                if (sc) {
                    const fromBottom = sc.scrollHeight - sc.scrollTop;
                    for (let i = 0; i < older; i++) {
                        const before = idCount(), top = firstId();
                        sc.scrollTop = 0;
                        sc.dispatchEvent(new Event('scroll'));
                        const grew = await waitFor(() => idCount() > before || firstId() !== top, 3500);
                        await openLongMessages();
                        items = merge(readAll(), items);
                        if (!grew) { reachedStart = true; break; }
                    }
                    sc.scrollTop = sc.scrollHeight - fromBottom;
                } else {
                    reachedStart = true;
                }
            }
            const info = chatInfo() || { name: '', jid: '', isGroup: false };
            const messages = items.filter((x) => x.id).length;
            return {
                status: 'chat',
                ...info,
                items,
                reachedStart,
                locale: navigator.language,
                seen: { rows: messageRows().length, messages, stamped: items.filter((x) => x.pre).length }
            };
        } finally {
            busy = false;
        }
    }

    chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
        if (msg && msg.type === 'c2s-ping') { reply({ ok: true }); }
        return false;
    });

    chrome.runtime.onConnect.addListener((port) => {
        if (port.name !== 'c2s') return;
        const keyNow = () => { const c = chatInfo(); return c ? `${c.name}|${c.jid}` : ''; };
        const newestNow = () => {
            const ids = main() ? main().querySelectorAll('[data-id]') : [];
            return ids.length ? ids[ids.length - 1].getAttribute('data-id') : null;
        };
        let key = keyNow();
        let newest = newestNow();
        let timer = null;
        const observer = new MutationObserver(() => {
            clearTimeout(timer);
            timer = setTimeout(() => {
                if (busy) return;
                const k = keyNow();
                if (k !== key) {
                    key = k; newest = newestNow();
                    port.postMessage({ type: 'changed', what: 'chat' });
                    return;
                }
                const n = newestNow();
                if (n !== newest) { newest = n; port.postMessage({ type: 'changed', what: 'messages' }); }
            }, 700);
        });
        observer.observe(document.body, { childList: true, subtree: true });
        port.onMessage.addListener(async (msg) => {
            if (!msg || msg.type !== 'read') return;
            let result;
            try {
                result = await read({ older: msg.older || 0 });
            } catch (e) {
                result = { status: 'error', message: String(e && e.message || e) };
            }
            key = keyNow();
            newest = newestNow();
            try { port.postMessage({ type: 'result', reqId: msg.reqId, ...result }); } catch { /* panel closed */ }
        });
        port.onDisconnect.addListener(() => { observer.disconnect(); clearTimeout(timer); });
    });
})();
