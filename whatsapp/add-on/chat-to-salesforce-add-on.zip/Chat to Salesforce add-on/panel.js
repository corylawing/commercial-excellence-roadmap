/*
 * THE ADD-ON'S PANEL BESIDE WHATSAPP WEB. The same app as the site (app.js, every screen and rule
 * shared); what differs is where the chat comes from: the chat open in WhatsApp Web, read by
 * whatsapp-reader.js on that page when this panel asks, and read again when the rep opens another
 * chat or a new message arrives. Sign-in goes through Chrome's own sign-in window.
 *
 * Loaded before app.js (panel.html): it sets globalThis.C2S_HOST, which app.js reads at start.
 */
import { CONFIG } from './sf.js';
import { linesFromItems, phoneFromJid } from './whatsapp-web.js';

const WA = 'https://web.whatsapp.com/';
const isWhatsApp = (url) => typeof url === 'string' && url.startsWith(WA);

CONFIG.redirectUri = chrome.identity.getRedirectURL();
CONFIG.display = 'popup';
CONFIG.openSignIn = (url) => new Promise((resolve, reject) => {
    chrome.identity.launchWebAuthFlow({ url, interactive: true }, (back) => {
        if (chrome.runtime.lastError || !back) reject(new Error(chrome.runtime.lastError ? chrome.runtime.lastError.message : 'closed'));
        else resolve(back);
    });
});

let api = null;
let port = null;
let tabId = null;
let status = { kind: 'looking' };
let current = null;          // { name, jid } of the chat on screen
let older = { reading: false, noMore: false };
let reqSeq = 0;
const waiting = new Map();

function setStatus(next) {
    status = next;
    if (!api) return;
    if (api.view() === 'chat' && next.kind !== 'chat') api.showHome();
    else api.refreshHome();
}

/* ------------------------------------------------------------ talking to the WhatsApp Web tab */

async function findTab() {
    const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (active && isWhatsApp(active.url)) return active;
    const here = await chrome.tabs.query({ url: `${WA}*`, currentWindow: true });
    if (here.length) return here[0];
    const anywhere = await chrome.tabs.query({ url: `${WA}*` });
    return anywhere[0] || null;
}

async function readerIsThere(id) {
    try {
        const r = await chrome.tabs.sendMessage(id, { type: 'c2s-ping' });
        return !!(r && r.ok);
    } catch {
        return false;
    }
}

let connecting = null;
function connect() {
    if (!connecting) connecting = connectNow().finally(() => { connecting = null; });
    return connecting;
}

async function connectNow() {
    if (!api) return;
    const tab = await findTab();
    if (!tab) { disconnect(); setStatus({ kind: 'no-tab' }); return; }
    if (port && tabId === tab.id) { read(); return; }
    disconnect();
    tabId = tab.id;
    if (!(await readerIsThere(tab.id))) {
        // WhatsApp Web was open before the add-on was installed: put the reader in now
        try {
            await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['whatsapp-reader.js'] });
        } catch {
            setStatus({ kind: 'loading' });
            return;
        }
    }
    port = chrome.tabs.connect(tab.id, { name: 'c2s' });
    port.onMessage.addListener(onPortMessage);
    port.onDisconnect.addListener(() => {
        port = null;
        for (const [, done] of waiting) done({ status: 'gone' });
        waiting.clear();
        setTimeout(connect, 800);   // the tab reloaded or closed
    });
    current = null;
    read();
}

function disconnect() {
    if (port) { try { port.disconnect(); } catch { /* already gone */ } }
    port = null;
    tabId = null;
}

function onPortMessage(msg) {
    if (msg.type === 'result' && waiting.has(msg.reqId)) {
        const done = waiting.get(msg.reqId);
        waiting.delete(msg.reqId);
        done(msg);
        return;
    }
    if (msg.type === 'changed') read({ quiet: msg.what === 'messages' });
}

function ask(payload) {
    return new Promise((resolve) => {
        if (!port) { resolve({ status: 'gone' }); return; }
        const reqId = ++reqSeq;
        waiting.set(reqId, resolve);
        port.postMessage({ ...payload, type: 'read', reqId });
    });
}

/* ------------------------------------------------------------ reading the chat */

let reading = null;
let again = null;
async function read(opts = {}) {
    if (reading) { again = { ...(again || {}), ...opts }; return reading; }
    reading = doRead(opts).finally(() => {
        reading = null;
        if (again) { const o = again; again = null; read(o); }
    });
    return reading;
}

async function doRead({ quiet = false, olderSteps = 0 } = {}) {
    if (!api) return;
    if (api.isBusy()) { setTimeout(() => read({ quiet }), 1000); return; }
    const r = await ask({ older: olderSteps });
    if (r.status === 'gone') return;
    if (r.status !== 'chat') { current = null; setStatus({ kind: r.status, message: r.message }); return; }
    const same = current && current.name === r.name && current.jid === r.jid && api.view() !== 'home';
    const built = linesFromItems(r.items, { chatName: r.name, isGroup: r.isGroup });
    if (!built.lines) {
        current = null;
        setStatus({ kind: r.seen && r.seen.messages ? 'unreadable' : 'empty', name: r.name, seen: r.seen });
        return;
    }
    const chat = {
        text: built.text,
        name: r.name,
        phone: r.isGroup ? null : phoneFromJid(r.jid),
        meName: built.meName,
        localeHint: r.locale,
        missingNote: 'stays in WhatsApp'
    };
    if (olderSteps) older = { reading: false, noMore: r.reachedStart };
    if (same) {
        api.updateChat(chat);
    } else {
        if (!quiet || api.view() === 'home') {
            older = { reading: false, noMore: false };
            status = { kind: 'chat' };
            current = { name: r.name, jid: r.jid };
            api.openChat(chat);
        }
    }
}

async function readOlder() {
    if (older.reading) return;
    older = { reading: true, noMore: false };
    api.refreshThread();
    while (reading) await reading;
    await read({ olderSteps: 4 });
    older.reading = false;
    api.refreshThread();
}

/* ------------------------------------------------------------ what the panel shows */

function homeCard({ pasteBox, icon, esc }) {
    const s = status;
    const spin = (words) => `<div class="searching wa-status"><span class="spinner"></span><span>${esc(words)}</span></div>`;
    const steps = (list) => `<ol class="steps3" aria-label="In WhatsApp Web">${list.map((t, i) => `<li><b>${i + 1}</b>${esc(t)}</li>`).join('')}</ol>`;
    switch (s.kind) {
        case 'looking': return spin('Looking for WhatsApp Web…');
        case 'loading': return spin('Waiting for WhatsApp Web to open…');
        case 'no-tab':
            return `<h1>Save a WhatsApp chat</h1>
                ${steps(['Open WhatsApp Web', 'Open the chat', 'Tick, then Save'])}
                <button class="btn primary big block" data-act="host-open">${icon('external')}Open WhatsApp Web</button>`;
        case 'not-linked':
            return `<h1>Link WhatsApp Web first</h1>
                <p class="muted">WhatsApp Web shows a code. On your phone, open WhatsApp › Settings › Linked devices › Link a device, and scan it.</p>`;
        case 'no-chat':
            return `<h1>Open a chat in WhatsApp Web</h1>
                ${steps(['Click a chat on the left', 'Its conversations show here', 'Tick, then Save'])}`;
        case 'empty':
            return `<h1>${esc(s.name || 'This chat')}</h1><p class="muted">No messages in this chat yet.</p>`;
        case 'unreadable':
        case 'error':
            return `<h1>This chat could not be read</h1>
                <p class="muted">WhatsApp Web may have changed. Copy the messages in WhatsApp Web and paste them here instead, and tell Cory.</p>
                <div class="btn-row"><button class="btn" data-act="host-retry">Try again</button><button class="btn primary" data-act="paste-open">Paste messages</button></div>
                ${pasteBox}
                <p class="faint">${esc(s.seen ? `Seen: ${s.seen.rows} rows, ${s.seen.messages} messages, ${s.seen.stamped} with a time` : s.message || '')}</p>`;
        default: return spin('Reading the chat…');
    }
}

function threadFooter({ esc }) {
    if (older.reading) return `<div class="searching more-earlier"><span class="spinner"></span><span>${esc('Reading earlier messages from WhatsApp…')}</span></div>`;
    if (older.noMore) return `<p class="faint more-earlier">${esc('That is as far back as WhatsApp Web goes.')} <button class="btn link" data-act="host-older">Try again</button></p>`;
    return '<button class="btn more-earlier" data-act="host-older">Read earlier messages</button>';
}

globalThis.C2S_HOST = {
    kind: 'extension',
    welcome: {
        question: 'Allow Chat to Salesforce to read the WhatsApp chat you have open?',
        points: [
            ['hand', 'It reads only the chat open in WhatsApp Web, and only while this panel is open. It never sends or changes a message.'],
            ['eye', 'You pick the conversations to keep. Only those are saved to Salesforce, on the doctor you confirm.'],
            ['shield', 'Nothing is sent anywhere else, and nothing from your chats is kept on this computer.']
        ],
        box: 'I allow Chat to Salesforce to read the WhatsApp chat I have open',
        button: 'Allow',
        done: 'WhatsApp Web allowed',
        locked: 'Next, allow Chat to Salesforce to read the chat you open in WhatsApp Web.'
    },
    cutNotice: (n, plural) => `${plural(n, 'long message', 'long messages')} could not be opened in full. Click “Read more” on ${n === 1 ? 'it' : 'them'} in WhatsApp Web and ${n === 1 ? 'it updates' : 'they update'} here.`,
    homeCard,
    threadFooter,
    ready(a) {
        api = a;
        status = { kind: 'looking' };
        connect();
    },
    onHome() { current = null; read(); },
    onStop() { disconnect(); api = null; current = null; },
    onAct(act) {
        if (act === 'host-open') chrome.tabs.create({ url: WA });
        else if (act === 'host-retry') { setStatus({ kind: 'reading' }); connect(); }
        else if (act === 'host-older') readOlder();
    }
};

/* The rep moves to another tab or opens WhatsApp Web: follow the WhatsApp Web tab in this window. */
chrome.tabs.onActivated.addListener(async ({ tabId: id }) => {
    if (!api || id === tabId) return;
    const tab = await chrome.tabs.get(id).catch(() => null);
    if (tab && isWhatsApp(tab.url)) connect();
});
chrome.tabs.onUpdated.addListener((id, change, tab) => {
    if (!api) return;
    if (change.status === 'complete' && isWhatsApp(tab.url) && (id === tabId || !port)) connect();
});
chrome.tabs.onRemoved.addListener((id) => {
    if (api && id === tabId) { disconnect(); connect(); }
});
