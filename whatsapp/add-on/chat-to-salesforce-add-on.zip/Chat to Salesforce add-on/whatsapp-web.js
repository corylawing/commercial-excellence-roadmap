/*
 * WHAT WHATSAPP WEB SHOWS, AS THE LINES THE APP ALREADY READS. The reader on web.whatsapp.com
 * (whatsapp-reader.js) hands over the chat's rows as they are on screen; this turns them into the
 * same "[10:32, 27/11/2026] Sophie Martin: Bonjour" lines WhatsApp itself writes when a rep copies
 * messages, so one parser (web/parser.js) reads every way a chat comes in.
 *
 * WhatsApp Web stamps every message that has words with that line (its data-pre-plain-text). A
 * photo, voice message or document sent without words carries no stamp: it takes its time from its
 * own bubble and its date from a stamped message under the same day heading.
 * Pure functions: no page, no network.
 */

const PRE = /^\[([^\],]+),\s*([^\]]+)\]\s?(.*?):\s?$/s;
const MARKER = {
    photo: 'image omitted', video: 'video omitted', voice: 'audio omitted', document: 'document omitted',
    sticker: 'sticker omitted', contact: 'Contact card omitted', gif: 'GIF omitted'
};

/* "[15:58, 26/11/2026] Lisa Speers: " → { time: '15:58', date: '26/11/2026', sender: 'Lisa Speers' } */
export function readPre(pre) {
    const m = PRE.exec(String(pre || '').replace(/[‎‏⁦-⁩]/g, ''));
    return m ? { time: m[1].trim(), date: m[2].trim(), sender: m[3].trim() } : null;
}

/* "33612345678@c.us" → "+33612345678". Groups (@g.us) and WhatsApp's hidden ids (@lid) carry no number. */
export function phoneFromJid(jid) {
    const m = /^(\d{7,15})@c\.us$/.exec(String(jid || ''));
    return m ? `+${m[1]}` : null;
}

/**
 * @param {Array<{sep?:string, id?:string, out?:boolean, pre?:string|null, text?:string, cut?:boolean,
 *                media?:string|null, time?:string|null}>} items  the chat's rows, oldest first
 * @param {{chatName?:string, isGroup?:boolean}} ctx
 * @returns {{ text:string, meName:string|null, lines:number, unread:number }}
 *          unread = rows that are messages but could not be read (no words and no time)
 */
export function linesFromItems(items, { chatName = '', isGroup = false } = {}) {
    let block = 0;
    const blocks = [];
    const rows = [];
    let meName = null;
    for (const it of items || []) {
        if (it.sep !== undefined) { block++; continue; }
        const p = readPre(it.pre);
        if (p) {
            if (!blocks[block]) blocks[block] = p.date;
            if (it.out && !meName) meName = p.sender;
        }
        rows.push({ ...it, block, p });
    }
    const out = [];
    let lastTheirs = null;
    let unread = 0;
    for (const r of rows) {
        if (r.p && !r.out) lastTheirs = r.p.sender;
        const words = String(r.text || '').replace(/\s+$/, '');
        if (r.p && words) {
            out.push(`[${r.p.time}, ${r.p.date}] ${r.p.sender}: ${words}${r.cut ? '\nRead more' : ''}`);
            continue;
        }
        if (!r.media) { unread++; continue; }
        const time = r.p ? r.p.time : r.time;
        const date = r.p ? r.p.date : blocks[r.block];
        const sender = r.p ? r.p.sender : r.out ? meName || 'You' : (isGroup ? lastTheirs : chatName) || chatName || 'WhatsApp';
        if (!time || !date) { unread++; continue; }
        out.push(`[${time}, ${date}] ${sender}: ${MARKER[r.media] || '<Media omitted>'}`);
    }
    return { text: out.join('\n'), meName: meName || (rows.some((r) => r.out && r.media && !r.p) ? 'You' : null), lines: out.length, unread };
}
